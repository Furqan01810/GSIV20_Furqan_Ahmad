export const API_KEY = '17c98c9bf8db191bad8a2bc215d9a97b';	
export const API_URL = 'https://api.themoviedb.org/3';	